#!/system/bin/sh
# RVC HAL overlay mount - KernelSU only.
# 用 OverlayFS 在 /vendor 上叠一层,把全新的 audio.primary.rvc.so 变成可见。
# - /data 是大小写不敏感(casefold)的 f2fs,overlayfs 拒绝当 upper → upper 放 /dev(tmpfs)
# - /dev 每次开机重建,天然无残留;脚本每次开机重建 upper/work
# - 不碰只读 erofs /vendor,不需要元模块
MODDIR="${1:-${0%/*}}"
OVL=/dev/rvc_overlay
UPPER=$OVL/upper/vendor
WORK=$OVL/work
LOGDIR=/data/adb/rvc_overlay
LOG=$LOGDIR/mount.log
SRC="$MODDIR/system/vendor/lib64/hw/audio.primary.rvc.so"

mkdir -p "$LOGDIR"
: > "$LOG"
log(){ echo "[$(date +%H:%M:%S)] $*" >> "$LOG"; }

# 已生效就直接退出
if [ -f /vendor/lib64/hw/audio.primary.rvc.so ]; then
    log "already visible via overlay; skip"
    exit 0
fi

# AIDL 音频 HAL 设备不加载 audio.primary.*.so,老 wrapper 无效:
# 探测到 AIDL 且没有真实(非 default)的 audio.primary.*.so 就直接退出,
# 不做无用的 overlay 挂载(App 侧也会拦截安装,这里是开机兜底)。
if ls /vendor/lib64/android.hardware.audio.core-*-ndk.so /vendor/lib/android.hardware.audio.core-*-ndk.so \
       /vendor/bin/hw/audiohalservice* /vendor/bin/hw/android.hardware.audio.service 2>/dev/null | head -1 | grep -q .; then
    if ! ls /vendor/lib64/hw/audio.primary.*.so /vendor/lib/hw/audio.primary.*.so 2>/dev/null | grep -v 'audio.primary.default.so' | grep -q .; then
        log "AIDL audio HAL detected; legacy wrapper not applicable"
        exit 0
    fi
fi

if [ ! -f "$SRC" ]; then
    log "ERROR: wrapper source missing: $SRC"
    exit 1
fi

# 重建 tmpfs upper/work(防上次残留)
rm -rf "$OVL" 2>/dev/null
mkdir -p "$UPPER/lib64/hw" "$WORK"

# 把 wrapper 放进 upper
cp -f "$SRC" "$UPPER/lib64/hw/audio.primary.rvc.so" || { log "ERROR: copy to upper failed"; exit 1; }
chmod 644 "$UPPER/lib64/hw/audio.primary.rvc.so"

# SELinux 上下文:对齐原厂 HAL(挂载前 /vendor 原样可读)
CTX=""
for ref in /vendor/lib64/hw/audio.primary.default.so /vendor/lib64/hw/audio.primary.taro.so; do
    if [ -f "$ref" ]; then
        CTX=$(ls -Zd "$ref" 2>/dev/null | awk '{print $1}')
        [ -n "$CTX" ] && break
    fi
done
if [ -n "$CTX" ]; then
    chcon "$CTX" "$UPPER/lib64/hw/audio.primary.rvc.so" 2>/dev/null || \
        chcon u:object_r:vendor_file:s0 "$UPPER/lib64/hw/audio.primary.rvc.so" 2>/dev/null || true
fi
chcon u:object_r:system_file:s0 "$UPPER" "$WORK" 2>/dev/null || true

# 挂 overlay 到 /vendor(source=KSU,让 KernelSU 认得这个挂载)
if mount -t overlay -o "lowerdir=/vendor,upperdir=$UPPER,workdir=$WORK" KSU /vendor 2>>"$LOG"; then
    log "overlay mounted OK"
else
    log "ERROR: overlay mount failed; falling back to default HAL"
    if command -v resetprop >/dev/null 2>&1; then
        resetprop ro.hardware.audio.primary default 2>>"$LOG" || true
    fi
    exit 1
fi

# 自检
if [ -f /vendor/lib64/hw/audio.primary.rvc.so ]; then
    log "OK: /vendor/lib64/hw/audio.primary.rvc.so visible"
else
    log "WARN: mounted but file not visible"
fi

# 如果 audioserver 已经起了,重启它让它重新加载 HAL(幂等)
if command -v pidof >/dev/null 2>&1 && [ -n "$(pidof audioserver 2>/dev/null)" ]; then
    stop audioserver 2>>"$LOG" || true
    start audioserver 2>>"$LOG" || true
    log "audioserver restarted"
fi

exit 0
