#!/system/bin/sh
# 在 Magisk 和 KernelSU 都会跑。只在 KernelSU 上做 overlay;
# Magisk 走经典 system/vendor 路径(已工作),这里什么都不做。
MODDIR="${0%/*}"
if [ -x /data/adb/ksud ] || [ -n "$KSU" ] || [ -n "$KSU_RUNTIME_MODE" ]; then
    exec sh "$MODDIR/mount-overlay.sh"
fi
exit 0
