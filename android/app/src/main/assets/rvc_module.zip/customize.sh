#!/system/bin/sh
# RVC Virtual Mic HAL - installer (non-replacing variant)
# 不顶替原厂 audio.primary.<soc>.so,避免原厂自引用导致递归加载。
# 安装 audio.primary.rvc.so,并用 system.prop 让系统优先加载它。

ui_print "- 安装 RVC 包装器 audio.primary.rvc.so"

OUT=$MODPATH/system/vendor/lib64/hw
mkdir -p "$OUT"

cp -f "$MODPATH/wrapper.so" "$OUT/audio.primary.rvc.so" || abort "!! 复制包装器失败"

chmod 644 "$OUT/audio.primary.rvc.so"
chown root:root "$OUT/audio.primary.rvc.so" 2>/dev/null || true

# root 中继:App 通过 su 拉起它,负责 HAL AF_UNIX <-> App TCP loopback 转发
chmod 755 "$MODPATH/rvc_relay" 2>/dev/null || true

# 参考一个真实 HAL 的 SELinux 上下文,保证音频服务能读/执行
REF=""
for f in /vendor/lib64/hw/audio.primary.taro.so /vendor/lib64/hw/audio.primary.default.so /vendor/lib/hw/audio.primary.default.so; do
    [ -f "$f" ] && REF="$f" && break
done
if [ -n "$REF" ]; then
    chcon --reference "$REF" "$OUT/audio.primary.rvc.so" 2>/dev/null || \
        abort "!! 设置 SELinux 上下文失败,中止安装"
else
    ui_print "!! 警告: 未找到参考 HAL,可能上下文不对"
fi

ui_print "- 完成: 包装器 = audio.primary.rvc.so,原厂 HAL 未改动"
ui_print "- 卸载模块即恢复原状"
