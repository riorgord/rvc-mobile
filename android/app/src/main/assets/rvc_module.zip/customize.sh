#!/system/bin/sh
# RVC Virtual Mic HAL - installer (non-replacing variant)
# 不顶替原厂 audio.primary.<soc>.so,避免原厂自引用导致递归加载。
# 安装 audio.primary.rvc.so,并用 system.prop 让系统优先加载它。
#
# 路径策略:
#   - system/vendor/lib64/hw/audio.primary.rvc.so : Magisk 传统路径(K50 已工作)
#   - KernelSU:模块脚本 late-load.sh/post-fs-data.sh 自己挂 OverlayFS,
#     不需要元模块,也不需要顶层 vendor 软链。
#
# 注意: KernelSU 更新已有模块时不一定重跑 customize.sh,所以
#       system/vendor 下的文件已直接内嵌在 zip 里,不依赖本脚本生成。

ui_print "- 安装 RVC 包装器 audio.primary.rvc.so"

# 兜底:确保 system/vendor 下文件存在(zip 已内嵌,这里只补缺)
if [ ! -f "$MODPATH/system/vendor/lib64/hw/audio.primary.rvc.so" ]; then
    mkdir -p "$MODPATH/system/vendor/lib64/hw"
    cp -f "$MODPATH/wrapper.so" "$MODPATH/system/vendor/lib64/hw/audio.primary.rvc.so" || abort "!! 复制包装器到 system/vendor 失败"
fi
chmod 644 "$MODPATH/system/vendor/lib64/hw/audio.primary.rvc.so" 2>/dev/null || true
chown root:root "$MODPATH/system/vendor/lib64/hw/audio.primary.rvc.so" 2>/dev/null || true

# root 中继:App 通过 su 拉起它,负责 HAL AF_UNIX <-> App TCP loopback 转发
chmod 755 "$MODPATH/rvc_relay" 2>/dev/null || true

# overlay 脚本权限
for f in mount-overlay.sh late-load.sh post-fs-data.sh uninstall.sh; do
    [ -f "$MODPATH/$f" ] && chmod 755 "$MODPATH/$f" 2>/dev/null || true
done

# 参考一个真实 HAL 的 SELinux 上下文,保证音频服务能读/执行
# 注意:KernelSU 安装环境不一定支持 chcon --reference,失败只警告不中止
REF=""
for f in /vendor/lib64/hw/audio.primary.taro.so /vendor/lib64/hw/audio.primary.default.so /vendor/lib/hw/audio.primary.default.so; do
    [ -f "$f" ] && REF="$f" && break
done
if [ -n "$REF" ]; then
    chcon --reference "$REF" "$MODPATH/system/vendor/lib64/hw/audio.primary.rvc.so" 2>/dev/null || \
        ui_print "!! 警告: 设置 system/vendor 的 SELinux 上下文失败(可稍后手动处理)"
else
    ui_print "!! 警告: 未找到参考 HAL,可能上下文不对"
fi

ui_print "- 完成: 包装器 = audio.primary.rvc.so,原厂 HAL 未改动"
ui_print "- 卸载模块即恢复原状"
