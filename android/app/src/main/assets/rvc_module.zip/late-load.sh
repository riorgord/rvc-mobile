#!/system/bin/sh
# KernelSU Next late-load hook:在 audioserver 起来前把 RVC HAL overlay 挂上。
exec sh "${0%/*}/mount-overlay.sh"
