#!/system/bin/sh
# rvc_relay root 中继开机自启(Magisk/KSU 模块 service.sh)
#  - 以 root 连接 HAL 的 AF_UNIX socket(/data/vendor/audio/rvc.sock)
#  - 监听 TCP 127.0.0.1:24681 给 App(App 不需要 root/su,不怕 su 被隐藏)
# 中继内部会自动每秒重试连 HAL socket,所以早点起也没关系。
MODDIR=${0%/*}

# 等服务阶段稳定一点再起,避免和早期系统初始化抢资源
(
    sleep 8
    if [ -x "$MODDIR/rvc_relay" ]; then
        setsid "$MODDIR/rvc_relay" >/dev/null 2>&1 < /dev/null &
    fi
) &
