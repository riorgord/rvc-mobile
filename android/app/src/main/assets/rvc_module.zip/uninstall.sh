#!/system/bin/sh
# 卸载时清掉 overlay 运行时数据(重启后 /dev 自动清空,/data 日志目录删干净)
rm -rf /dev/rvc_overlay 2>/dev/null || true
rm -rf /data/adb/rvc_overlay 2>/dev/null || true
exit 0
